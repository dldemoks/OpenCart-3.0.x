<?php
// Text
$_['text_title'] = 'Payeer';
$_['text_email_subject'] = 'Ошибка оплаты';
$_['text_email_message1'] = 'Не удалось произвести оплату через систему Payeer по следующим причинам:';
$_['text_email_message2'] = ' - Цифровая подпись неверная';
$_['text_email_message3'] = ' - The payment status is not success';
$_['text_email_message4'] = ' - IP-адрес сервера не является доверенным';
$_['text_email_message5'] = '   доверенные IP: ';
$_['text_email_message6'] = '   IP текущего сервера: ';
$_['text_email_message7'] = ' - Неправильная сумма';
$_['text_email_message8'] = ' - Неправильная валюта';
$_['text_email_message9'] = ' - Заказ не существует';