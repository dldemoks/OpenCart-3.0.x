<?php
// Text
$_['text_title'] = 'Payeer';
$_['text_email_subject'] = 'Payment error';
$_['text_email_message1'] = 'Failed to make the payment through the system Payeer for the following reasons:';
$_['text_email_message2'] = ' - Do not match the digital signature';
$_['text_email_message3'] = ' - The payment status is not success';
$_['text_email_message4'] = ' - the ip address of the server is not trusted';
$_['text_email_message5'] = '   trusted ip: ';
$_['text_email_message6'] = '   ip of the current server: ';
$_['text_email_message7'] = ' - Wrong amount';
$_['text_email_message8'] = ' - Wrong currency';
$_['text_email_message9'] = ' - The order does not exist';